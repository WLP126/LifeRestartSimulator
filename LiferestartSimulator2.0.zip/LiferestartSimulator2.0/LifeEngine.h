#ifndef LIFEENGINE_H
#define LIFEENGINE_H

#include <QObject>
#include <QString>
#include <QVector>
#include <QMap>
#include <QStringList>
#include "LifeEvent.h" // 引入新的事件结构和属性结构

// 主游戏逻辑引擎类
class LifeEngine : public QObject {
    Q_OBJECT

public:
    explicit LifeEngine(QObject *parent = nullptr);

    // 启动/重新开始人生
    void startNewLife();
    // 玩家做出某个选项后的处理
    void makeChoice(int index);

    // 获取当前属性、年龄、事件等供 UI 展示
    Attribute currentAttributes() const { return m_attributes; }
    int currentAge() const { return m_age; }
    QString currentEventDescription() const { return m_currentEvent.description; }
    QStringList currentChoices() const { return m_currentEvent.choices; }
    QString lifeSummary() const;

public slots:
    void proceedToNextYear();

signals:
    void gameUpdated();     // 每次事件刷新时发送
    void gameOver(QString); // 游戏结束时发送

private:
    void loadEvents();               // 加载所有事件
    void triggerNextEvent();         // 根据当前年龄触发新事件
    void determineEducationStage();  // 判断就读学校类型
    void evaluateEndConditions();    // 判断是否结束
    void nextYear();                 // 年龄加一，处理自然变化

    int m_age;                       // 当前年龄
    bool m_gameOver;                 // 游戏是否结束
    Attribute m_attributes;          // 当前属性
    LifeEvent m_currentEvent;        // 当前事件
    QVector<LifeEvent> m_allEvents;  // 所有可触发事件
    QStringList m_lifeRecord;        // 日志记录
    QMap<QString, bool> m_flags;     // 关键路径选择
    QString m_educationStage;        // 当前教育阶段
};

#endif // LIFEENGINE_H
