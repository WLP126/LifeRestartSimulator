#ifndef LIFEEVENT_H
#define LIFEEVENT_H

#include <QString>
#include <QStringList>
#include <QVector>

// 属性结构体
struct Attribute {
    int intelligence;
    int wealth;
    int health;
    int happiness;
    int appearance;

    Attribute(int i = 0, int w = 0, int h = 0, int ha = 0, int a = 0)
        : intelligence(i), wealth(w), health(h), happiness(ha), appearance(a) {}
};

// 事件结构体
struct LifeEvent {
    QString description;             // 事件描述
    int minAge;                      // 最小年龄
    int maxAge;                      // 最大年龄
    QStringList choices;            // 可选项
    QVector<Attribute> effects;     // 每个选项对应的属性变化
    QString flagIfChosen;           // 若选择此事件设置的flag
    bool isMainEvent;               // 是否为主线事件
    QStringList requiredFlags;      // 触发该事件所需flags
    QStringList excludedFlags;      // 若存在某些flags则排除此事件
    QStringList tags;               // 事件分类标签（例如：情感、家庭、职业）

    // 默认构造函数
    LifeEvent()
        : minAge(0), maxAge(0), isMainEvent(false) {}

    // 全参数构造函数
    LifeEvent(const QString &desc, int minA, int maxA,
              const QStringList &chs, const QVector<Attribute> &eff,
              const QString &flag = QString(),
              bool main = false,
              const QStringList &required = {},
              const QStringList &excluded = {},
              const QStringList &tagList = {})
        : description(desc), minAge(minA), maxAge(maxA),
          choices(chs), effects(eff), flagIfChosen(flag),
          isMainEvent(main),
          requiredFlags(required),
          excludedFlags(excluded),
          tags(tagList) {}
};

#endif // LIFEEVENT_H

