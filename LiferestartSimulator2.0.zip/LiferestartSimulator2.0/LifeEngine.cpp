#include "LifeEngine.h"
#include "LifeEvent.h"
#include <QRandomGenerator>
#include <QDebug>
#include <QTimer>

LifeEngine::LifeEngine(QObject *parent) : QObject(parent), m_age(0), m_gameOver(false) {
    loadEvents();
}

void LifeEngine::startNewLife() {
    m_attributes = Attribute(
        QRandomGenerator::global()->bounded(20, 41),
        QRandomGenerator::global()->bounded(20, 41),
        QRandomGenerator::global()->bounded(20, 41),
        QRandomGenerator::global()->bounded(20, 41),
        QRandomGenerator::global()->bounded(20, 41)
    );
    m_age = 0;
    m_gameOver = false;
    m_lifeRecord.clear();
    m_flags.clear();
    m_educationStage = "幼儿";

    m_lifeRecord << "你出生了！初始属性："
                 << QString("智力:%1 财富:%2 健康:%3 幸福:%4 颜值:%5")
                        .arg(m_attributes.intelligence)
                        .arg(m_attributes.wealth)
                        .arg(m_attributes.health)
                        .arg(m_attributes.happiness)
                        .arg(m_attributes.appearance);

    triggerNextEvent();
    emit gameUpdated();
}

void LifeEngine::makeChoice(int index) {
    if (m_gameOver || index < 0 || index >= m_currentEvent.choices.size()) return;

    m_lifeRecord << QString("[%1岁] %2 -> 选择：%3")
                    .arg(m_age)
                    .arg(m_currentEvent.description)
                    .arg(m_currentEvent.choices[index]);

    // 应用属性效果
    Attribute effect = m_currentEvent.effects[index];
    m_attributes.intelligence = qBound(0, m_attributes.intelligence + effect.intelligence, 100);
    m_attributes.wealth = qBound(0, m_attributes.wealth + effect.wealth, 100);
    m_attributes.health = qBound(0, m_attributes.health + effect.health, 100);
    m_attributes.happiness = qBound(0, m_attributes.happiness + effect.happiness, 100);
    m_attributes.appearance = qBound(0, m_attributes.appearance + effect.appearance, 100);

    // 设置flag
    if (!m_currentEvent.flagIfChosen.isEmpty()) {
        m_flags[m_currentEvent.flagIfChosen] = true;
    }

    proceedToNextYear();
}


void LifeEngine::proceedToNextYear() {
    if (m_gameOver) return;

    m_age++;
    m_lifeRecord << QString("---- %1 岁 ----").arg(m_age);

    // 年龄自然影响健康
    if (m_age > 60) m_attributes.health -= 1;
    m_attributes.health = qMax(0, m_attributes.health);

    // ✅ 检查健康是否为 0，若为 0 则立即结束
    if (m_attributes.health <= 0) {
        m_gameOver = true;
        m_lifeRecord << QString("你的健康已耗尽，你在 %1 岁时离开了人世。").arg(m_age);
        emit gameOver(lifeSummary());
        return;  // ⛔️ 不再触发事件
    }

    determineEducationStage();
    triggerNextEvent();

    if (m_currentEvent.description.isEmpty()) {
        m_lifeRecord << QString("年龄 %1：这一年平安无事").arg(m_age);
        emit gameUpdated();
        QTimer::singleShot(500, this, [this]() { proceedToNextYear(); });
        return;
    }

    evaluateEndConditions();
}


void LifeEngine::evaluateEndConditions() {
    if (m_attributes.health <= 0) {
        m_gameOver = true;
        m_lifeRecord << QString("你的健康已耗尽，你在 %1 岁时离开了人世。").arg(m_age);
        emit gameOver(lifeSummary());
    } else if (m_age >= 100 || m_flags.contains("immortal")) {
        m_gameOver = true;
        if (m_flags.contains("immortal")) {
            m_lifeRecord << "你修炼多年，终于羽化飞升，超脱世俗人生。";
        } else {
            m_lifeRecord << "你平静地活过一生，在100岁寿终正寝。";
        }
        emit gameOver(lifeSummary());
    } else {
        emit gameUpdated();  // 正常更新界面
    }
}


void LifeEngine::determineEducationStage() {
    if (m_age == 7) {
        if (m_attributes.intelligence >= 18) m_educationStage = "重点小学";
        else if (m_attributes.happiness >= 15) m_educationStage = "贵族小学";
        else m_educationStage = "普通小学";
        m_lifeRecord << "你进入了：" + m_educationStage;
    } else if (m_age == 13) {
        if (m_attributes.intelligence >= 30) m_educationStage = "重点初中";
        else if (m_attributes.happiness >= 20) m_educationStage = "贵族初中";
        else m_educationStage = "普通初中";
        m_lifeRecord << "你升入了：" + m_educationStage;
    } else if (m_age == 16) {
        if (m_flags.contains("early_love")) m_educationStage = "普通高中";
        else if (m_attributes.intelligence >= 45) m_educationStage = "重点高中";
        else m_educationStage = "普通高中";
        m_lifeRecord << "你进入了：" + m_educationStage;
    } else if (m_age == 19) {
        if (m_attributes.intelligence >= 60) m_educationStage = "重点大学";
        else if (m_flags.contains("art_path")) m_educationStage = "艺术大学";
        else m_educationStage = "普通大学";
        m_lifeRecord << "你被录取到了：" + m_educationStage;
    }
}

void LifeEngine::loadEvents() {
    m_allEvents.clear();

    // 出生
    m_allEvents.append(LifeEvent("你出生了，这个世界向你敞开了大门！", 0, 0,
        {"哇哇大哭", "睁眼看世界"},
        {Attribute(0, 0, 0, 1, 0), Attribute(1, 0, 0, 0, 1)},
        "", true, {}, {}));

    // 学龄前
    m_allEvents.append(LifeEvent("你是否上兴趣班（美术/体育）？", 6, 6,
        {"报名美术班", "学习体操", "不参与"},
        {Attribute(1, 0, 0, 1, 1), Attribute(0, 0, 2, 1, 0), Attribute(0, 0, 0, 0, 0)},
        "preschool_interest", false, {}, {}));

    //小学
    m_allEvents.append(LifeEvent("你准备进入小学，老师评估你的能力…", 7, 7,
        {"等待分班"},
        {Attribute()},
        "primary_school", true, {}, {}));

    m_allEvents.append(LifeEvent("你在小学是否参加课外活动？", 10, 10,
        {"参加编程兴趣班", "学外语", "都没兴趣"},
        {Attribute(2, 0, 0, 1, 0), Attribute(2, 0, 0, 0, 0), Attribute(0, 0, 0, 0, 0)},
        "", false, {}, {}));

    //初高中
    m_allEvents.append(LifeEvent("你初中入学，面对新环境：", 13, 13,
        {"专注学习", "积极交友", "发展爱好"},
        {Attribute(3, 0, 0, 0, 0), Attribute(0, 0, 0, 2, 0), Attribute(1, 0, 0, 1, 0)},
        "", true, {}, {}));

    m_allEvents.append(LifeEvent("初中，你暗恋班上的TA，你…", 14, 14,
        {"勇敢表白", "默默喜欢", "收心学习"},
        {Attribute(0, 0, -1, 2, 0), Attribute(0, 0, 0, 1, 0), Attribute(2, 0, 0, 0, 0)},
        "early_love", false, {}, {}));

    m_allEvents.append(LifeEvent("你正在准备高考，你…", 18, 18,
        {"努力拼搏", "佛系应对", "想去艺术类院校"},
        {Attribute(3, 0, -2, -1, 0), Attribute(0, 0, 0, 1, 0), Attribute(1, 0, 0, 1, 1)},
        "college_path", true, {}, {}));

    m_allEvents.append(LifeEvent("大学社团招新，你…", 18, 18,
        {"加入科技社", "加入文艺团", "不参与"},
        {Attribute(2, 0, -1, 2, 0), Attribute(1, 0, 0, 3, 1), Attribute(0, 0, 0, 0, 0)},
        "", false, {}, {}));

    m_allEvents.append(LifeEvent("你遇到了心动的她/他", 19, 19,
        {"追求并恋爱", "保持距离", "继续单身"},
        {Attribute(0, 0, -1, 3, 1), Attribute(0, 0, 0, 1, 0), Attribute(1, 0, 0, 0, 0)},
        "college_love", false, {}, {}));


    // 职业路线
    m_allEvents.append(LifeEvent("毕业后，你的职业选择是：", 22, 22,
        {"国企", "大厂", "自由职业"},
        {Attribute(1, 3, 0, 1, 0), Attribute(2, 5, -2, -1, 0), Attribute(1, 2, 0, 0, 0)},
        "job_path", true, {}, {}));

    m_allEvents.append(LifeEvent("你再次遇到大学恋人，或者新相识", 24, 24,
        {"发展恋情", "犹豫观望", "专注事业"},
        {Attribute(0, 0, -1, 3, 0), Attribute(0, 0, 0, 0, 0), Attribute(1, 2, 0, -1, 0)},
        "love_continues", false, {}, {}));

    //婚姻线
    m_allEvents.append(LifeEvent("结婚前，你们就彩礼和房子产生分歧", 25, 25,
        {"努力满足", "妥协解决", "最终放弃"},
        {Attribute(-2, -5, -1, -1, 0), Attribute(0, -2, 0, 1, 0), Attribute(0, 0, 0, -2, 0)},
        "marriage_ready", false, {"love_continues"}, {}));

    m_allEvents.append(LifeEvent("你们决定是否结婚：", 26, 26,
        {"结婚", "错过缘分"},
        {Attribute(0, -2, -1, 2, 0), Attribute(0, 0, 0, -1, 0)},
        "married", false, {"love_continues"}, {}));

    m_allEvents.append(LifeEvent("你在30岁的朋友聚会上邂逅了一位志同道合的人，你…", 30, 30,
        {"尝试发展关系", "保持普通朋友", "继续独身奋斗"},
        {Attribute(0, 0, -1, 3, 1), Attribute(0, 0, 0, 1, 0), Attribute(1, 2, 0, -1, 0)},
        "late_love", false, {}, {"married"}));

    //孩子线
    m_allEvents.append(LifeEvent("你考虑是否要孩子？", 28, 28,
        {"要", "不要"},
        {Attribute(0, -3, -2, 3, 0), Attribute(0, 0, 0, 0, 0)},
        "has_child", false, {"married"}, {}));

    m_allEvents.append(LifeEvent("孩子出生了！", 30, 30,
        {"给TA最好的教育"},
        {Attribute(-1, -3, -2, 3, 0)},
        "child_born", false, {"has_child"}, {}));


    m_allEvents.append(LifeEvent("孩子上幼儿园/小学", 35, 35,
        {"报私立", "报公立"},
        {Attribute(-2, -5, 0, 1, 0), Attribute(0, 0, 0, 0, 0)},
        "", false, {"child_born"}, {}));

    m_allEvents.append(LifeEvent("你开始求职面试", 24, 24,
        {"加入大厂", "去创业公司", "进国企"},
        {Attribute(1, 3, -1, -1, 0), Attribute(1, 2, -2, 0, 0), Attribute(0, 2, 0, 0, 0)},
        "", false, {}, {}));

    m_allEvents.append(LifeEvent("你获得升职机会", 27, 27,
        {"争取机会", "稳妥观望"},
        {Attribute(2, 5, -1, 0, 0), Attribute(0, 0, 0, 1, 0)},
        "", false, {}, {}));

    m_allEvents.append(LifeEvent("你是否考虑跳槽或出国？", 31, 31,
        {"跳槽", "留守", "创业"},
        {Attribute(1, 4, -1, 0, 0), Attribute(0, 0, 0, 1, 0), Attribute(2, 8, -2, -2, 0)},
        "", false, {}, {}));

    m_allEvents.append(LifeEvent("中年焦虑袭来", 40, 40,
        {"运动放松", "寻找意义", "内耗焦虑"},
        {Attribute(0, 0, 1, 3, 0), Attribute(1, 0, 0, 1, 0), Attribute(0, 0, -2, -3, 0)},
        "", false, {}, {}));

    m_allEvents.append(LifeEvent("你仍未结婚，有人建议你追求更自由的人生", 30, 30,
        {"专注事业", "考虑出国", "潜心修行"},
        {Attribute(2, 3, 0, 1, 0), Attribute(1, 5, -1, 2, 0), Attribute(3, 0, 0, 3, 0)},
        "independent_path", false, {}, {"married", "has_child"}));

    m_allEvents.append(LifeEvent("你加入了公益组织，开始奉献社会", 32, 32,
        {"投入志愿服务", "偶尔帮忙", "没有兴趣"},
        {Attribute(0, 0, 0, 3, 0), Attribute(0, 0, 0, 1, 0), Attribute(0, 0, 0, -1, 0)},
        "", false, {"independent_path"}, {}));

    m_allEvents.append(LifeEvent("你遇到一位灵魂伴侣，但你是否还愿意再开始？", 36, 36,
        {"接受他/她", "保持朋友", "继续独处"},
        {Attribute(0, 0, 0, 3, 1), Attribute(0, 0, 0, 1, 0), Attribute(1, 1, 0, 0, 0)},
        "late_love", false, {"independent_path"}, {}));

    m_allEvents.append(LifeEvent("你过着独居生活", 40, 40,
        {"养只猫陪伴", "沉迷工作", "习惯孤独"},
        {Attribute(0, 0, 0, 2, 0), Attribute(2, 3, -1, 0, 0), Attribute(0, 0, 0, 0, 0)},
        "", false, {"independent_path"}, {}));


    // 45岁：偶遇灵魂伴侣
    m_allEvents.append(LifeEvent("你在一次展览上邂逅了一位与你灵魂共鸣的人", 45, 45,
        {"主动交流", "礼貌寒暄", "转身离开"},
        {Attribute(0,0,0,3,0), Attribute(0,0,0,1,0), Attribute(0,0,0,0,0)},
        "late_love",
        "情感",
        {"late_love"}
    ));

    m_allEvents.append(LifeEvent("你与那位灵魂伴侣开始频繁交流...", 46, 46,
        {"共度时光", "保持朋友", "疏远"},
        {Attribute(0,0,0,3,0), Attribute(0,0,0,1,0), Attribute(0,0,0,-1,0)},
        "",
        "情感",
        {"late_love"}
    ));

    m_allEvents.append(LifeEvent("你们的关系逐渐深入，是否考虑一起生活？", 50, 50,
        {"一起生活", "维持距离关系"},
        {Attribute(0,0,0,4,0), Attribute(0,0,0,1,0)},
        "late_married",
        "情感",
        {"late_love", "late_married"}
    ));

    m_allEvents.append(LifeEvent("你感觉婚姻渐渐失去激情，你会……", 32, 32,
        {"主动沟通挽回", "选择冷处理", "投入事业逃避"},
        {Attribute(0,0,0,3,0), Attribute(0,0,0,-2,0), Attribute(2,2,0,-1,0)},
        "",
        "婚姻",
        {"married"}
    ));

    m_allEvents.append(LifeEvent("你的孩子进入叛逆期，和你冲突不断。你……", 36, 36,
        {"耐心沟通", "强硬管教", "交给配偶处理"},
        {Attribute(0,0,-1,2,0), Attribute(0,0,0,-1,0), Attribute(0,0,0,0,0)},
        "",
        "家庭",
        {"has_child"}
    ));

    m_allEvents.append(LifeEvent("多年好友渐渐疏远，你是否主动联系？", 38, 38,
        {"主动联络", "顺其自然"},
        {Attribute(0,0,0,2,0), Attribute(0,0,0,0,0)},
        "",
        "社交",
        {}
    ));

    m_allEvents.append(LifeEvent("公司改革，你被要求接受调岗", 42, 42,
        {"接受挑战", "辞职换工作", "拒绝调岗"},
        {Attribute(2,3,-1,1,0), Attribute(0,2,-2,0,0), Attribute(0,0,0,-2,0)},
        "",
        "职业",
        {"job_path"}
    ));

    m_allEvents.append(LifeEvent("体检发现血压偏高，你决定……", 45, 45,
        {"开始健身", "注意饮食", "忽略"},
        {Attribute(0,0,2,1,0), Attribute(0,0,1,0,0), Attribute(0,0,-2,-1,0)},
        "",
        "健康",
        {}
    ));

    m_allEvents.append(LifeEvent("父母年迈，一位亲人去世。你感到……", 48, 48,
        {"深切怀念", "反思人生", "继续前行"},
        {Attribute(0,0,0,-2,0), Attribute(1,0,0,1,0), Attribute(0,0,0,0,0)},
        "",
        "家庭",
        {}
    ));

    m_allEvents.append(LifeEvent("你出版了人生第一本书，反响热烈！", 52, 52,
        {"开启副业写作", "一书封笔"},
        {Attribute(2,3,0,3,0), Attribute(0,0,0,2,0)},
        "",
        "成就",
        {"entrepreneur"}
    ));

    m_allEvents.append(LifeEvent("你考虑是否提前退休", 58, 58,
        {"退休", "再干几年"},
        {Attribute(0,-2,1,2,0), Attribute(0,2,-1,0,0)},
        "",
        "晚年",
        {}
    ));

    m_allEvents.append(LifeEvent("是否移居郊区/海外", 60, 60,
        {"海外养老", "郊区居住", "城市生活"},
        {Attribute(0,-1,1,2,0), Attribute(0,0,1,1,0), Attribute(0,0,0,0,0)},
        "",
        "晚年",
        {}
    ));

    m_allEvents.append(LifeEvent("孙辈出生，你是否照顾", 65, 65,
        {"积极照顾", "偶尔帮忙", "过自己生活"},
        {Attribute(0,0,-1,4,0), Attribute(0,0,0,2,0), Attribute(0,0,0,1,0)},
        "",
        "家庭",
        {}
    ));

    m_allEvents.append(LifeEvent("回忆你的一生", 75, 75,
        {"翻阅日记"},
        {Attribute(0,0,0,0,0)},
        "",
        "晚年",
        {}
    ));

    m_allEvents.append(LifeEvent("你步入高龄，是否悟出人生真谛？", 90, 90,
        {"悟道成仙", "安然终老"},
        {Attribute(0,0,100,10,0), Attribute(0,0,0,5,0)},
        "immortal",
        "结局",
        {"immortal"}
    ));
}


void LifeEngine::triggerNextEvent() {
    QVector<LifeEvent> candidates;

    for (const LifeEvent &e : m_allEvents) {
        // 年龄范围判断
        if (m_age < e.minAge || m_age > e.maxAge)
            continue;

        // 自由人生分支排除婚姻、家庭类事件
        if (m_flags.contains("independent_path")) {
            if (e.tags.contains("婚姻") || e.tags.contains("家庭") || e.tags.contains("情感"))
                continue;
        }

        // 如果事件需要某些 flags，检查是否全部满足
        if (!e.requiredFlags.isEmpty()) {
            bool allMatched = std::all_of(e.requiredFlags.begin(), e.requiredFlags.end(), [this](const QString &flag) {
                return m_flags.value(flag, false);
            });
            if (!allMatched)
                continue;
        }

        // 如果事件排除某些 flags，任意一个存在就跳过
        if (!e.excludedFlags.isEmpty()) {
            bool anyExcluded = std::any_of(e.excludedFlags.begin(), e.excludedFlags.end(), [this](const QString &flag) {
                return m_flags.value(flag, false);
            });
            if (anyExcluded)
                continue;
        }

        candidates.append(e);
    }

    if (!candidates.isEmpty()) {
        int idx = QRandomGenerator::global()->bounded(candidates.size());
        m_currentEvent = candidates[idx];
        m_lifeRecord << QString("【%1岁】触发事件：%2").arg(m_age).arg(m_currentEvent.description);
    } else {
        m_currentEvent = LifeEvent();
        m_lifeRecord << QString("年龄 %1：这一年平安无事").arg(m_age);
    }
}



QString LifeEngine::lifeSummary() const {
    QString summary = "=== 人生总结 ===\n";
    for (const QString &s : m_lifeRecord) {
        summary += s + "\n";
    }

    int score = (
        m_attributes.intelligence * 15 +
        m_attributes.wealth * 30 +
        m_attributes.happiness * 25 +
        m_attributes.appearance * 10
    ) / 80;  // 新权重总和为 80，保证满分仍为 100

    // 如果是修仙，直接特判
    if (m_flags.contains("immortal")) {
        summary += "🕊️ 你已经踏上修仙之路，超脱评分系统！";
    } else {
        summary += "\n=== 最终评价 ===\n";

        if (score >= 95) {
            summary += "🌟 神话人生：你已达巅峰，书写传说。";
        } else if (score >= 85) {
            summary += "🏆 传奇人生：事业爱情双丰收，众人羡慕。";
        } else if (score >= 70) {
            summary += "👍 优秀人生：你留下了浓墨重彩的一笔。";
        } else if (score >= 55) {
            summary += "📘 平凡人生：你过得稳定而温馨。";
        } else if (score >= 40) {
            summary += "😓 艰难人生：你咬牙坚持到最后。";
        } else if (score >= 25) {
            summary += "☁️ 遗憾人生：很多事你本可以做得更好。";
        } else {
            summary += "☠️ 悲惨人生：一路坎坷，但希望仍在重来。";
        }
    }


    summary += QString("\n\n最终属性：\n智力:%1 财富:%2 健康:%3 幸福:%4 颜值:%5\n最终年龄：%6")
        .arg(m_attributes.intelligence)
        .arg(m_attributes.wealth)
        .arg(m_attributes.health)
        .arg(m_attributes.happiness)
        .arg(m_attributes.appearance)
        .arg(m_age);

    summary += "\n\n关键人生节点：";
    if (m_flags.value("art_path")) summary += "\n🎨 你曾走过一条艺术之路";
    if (m_flags.value("early_love")) summary += "\n❤️ 你年少时陷入爱情";
    if (m_flags.value("has_child")) summary += "\n👶 你育有子女，尽心尽力";
    if (m_flags.value("entrepreneur")) summary += "\n💼 你曾勇敢创业，拼搏奋斗";
    if (m_flags.value("independent_path")) summary += "\n🌱 你选择了一条自由而独立的人生之路";

    return summary;
}
