#include "LifeWindow.h"
#include <QFontDatabase>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QTextBrowser>
#include <QTextEdit>
#include <QTimer>
#include <QPropertyAnimation>
#include <QScrollBar>
#include <QDebug>

LifeWindow::LifeWindow(QWidget *parent)
    : QMainWindow(parent),
      m_engine(new LifeEngine(this)),
      m_typeTimer(new QTimer(this))
{
    setFixedSize(1000, 600);
    setWindowTitle("人生重开模拟器");

    // 创建游戏容器 container，固定大小 + 居中 + 半透明
    container = new QWidget(this);
    container->setFixedSize(900, 550);
    container->move((width() - 900) / 2, (height() - 550) / 2);
    container->setStyleSheet(R"(
        background-color: rgba(255, 255, 255, 230);
        border-radius: 16px;
        border: 1px solid #ccc;
    )");

    // 页面堆叠器
    stackedWidget = new QStackedWidget(container);
    stackedWidget->setStyleSheet("background: transparent;");

    QVBoxLayout *containerLayout = new QVBoxLayout(container);
    containerLayout->addWidget(stackedWidget);

    // === Start Page ===
    startPage = new QWidget;
    QVBoxLayout *startLayout = new QVBoxLayout(startPage);
    QLabel *titleLabel = new QLabel("🎮 人生重开模拟器");
    titleLabel->setStyleSheet("font: bold 28px 'Microsoft YaHei'; color: #333;");
    titleLabel->setAlignment(Qt::AlignCenter);
    startLayout->addWidget(titleLabel);

    QPushButton *startButton = new QPushButton("重开人生");
    startButton->setFixedSize(200, 60);
    startButton->setStyleSheet(R"(
        QPushButton {
            background-color: #28a745;
            color: white;
            font: bold 18px 'Microsoft YaHei';
            border-radius: 10px;
        }
        QPushButton:hover {
            background-color: #218838;
        }
    )");
    startLayout->addStretch();
    startLayout->addWidget(startButton, 0, Qt::AlignCenter);
    startLayout->addStretch();
    connect(startButton, &QPushButton::clicked, this, &LifeWindow::onStartClicked);

    // === Game Page ===
    gamePage = new QWidget;
    QVBoxLayout *gameLayout = new QVBoxLayout(gamePage);

    QHBoxLayout *topLayout = new QHBoxLayout;
    QVBoxLayout *attrLayout = new QVBoxLayout;
    ageLabel = new QLabel("年龄：");
    intelLabel = new QLabel("智力：");
    wealthLabel = new QLabel("财富：");
    healthLabel = new QLabel("健康：");
    happyLabel = new QLabel("幸福：");
    appearLabel = new QLabel("颜值：");

    for (auto *label : { ageLabel, intelLabel, wealthLabel, healthLabel, happyLabel, appearLabel }) {
        label->setFont(QFont("Microsoft YaHei", 14));
        label->setStyleSheet("color: #222; padding: 4px;");
        attrLayout->addWidget(label);
    }

    logText = new QTextBrowser;
    logText->setMinimumSize(400, 250);
    logText->setStyleSheet(R"(
        background: white;
        border-radius: 10px;
        font: 13px 'Microsoft YaHei';
        border: 1px solid #ddd;
        padding: 10px;
    )");
    topLayout->addLayout(attrLayout);
    topLayout->addWidget(logText);
    gameLayout->addLayout(topLayout);

    eventLabel1 = new QLabel("事件将显示在这里。");
    eventLabel1->setWordWrap(true);
    eventLabel1->setStyleSheet("font: 14px 'Microsoft YaHei'; background-color: #f9f9f9; border: 1px solid #ccc; padding: 10px; border-radius: 6px;");
    gameLayout->addWidget(eventLabel1);

    QHBoxLayout *choiceLayout = new QHBoxLayout;
    QString buttonStyle = R"(
        QPushButton {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            font: 14px 'Microsoft YaHei';
            border-radius: 6px;
        }
        QPushButton:hover {
            background-color: #45a049;
        }
    )";
    for (int i = 0; i < 4; ++i) {
        m_choiceButtons[i] = new QPushButton(QString("选项%1").arg(i + 1));
        m_choiceButtons[i]->setStyleSheet(buttonStyle);
        m_choiceButtons[i]->setVisible(false);
        choiceLayout->addWidget(m_choiceButtons[i]);
        connect(m_choiceButtons[i], &QPushButton::clicked, [this, i]() { onChoiceMade(i); });
    }

    nextYearButton = new QPushButton("进入下一年");
    nextYearButton->setStyleSheet(buttonStyle);
    nextYearButton->setVisible(false);
    gameLayout->addWidget(nextYearButton);
    connect(nextYearButton, &QPushButton::clicked, this, [this]() {
        m_engine->proceedToNextYear();
    });
    choiceLayout->addWidget(nextYearButton);
    gameLayout->addLayout(choiceLayout);

    // === Summary Page ===
    summaryPage = new QWidget;
    QVBoxLayout *summaryLayout = new QVBoxLayout(summaryPage);
    summaryTextEdit = new QTextEdit;
    summaryTextEdit->setReadOnly(true);
    summaryTextEdit->setStyleSheet("font: 14px 'Microsoft YaHei'; background-color: white; padding: 10px; border-radius: 8px;");
    summaryLayout->addWidget(summaryTextEdit);

    stackedWidget->addWidget(startPage);
    stackedWidget->addWidget(gamePage);
    stackedWidget->addWidget(summaryPage);

    setWindowOpacity(0);
    QPropertyAnimation *fadeIn = new QPropertyAnimation(this, "windowOpacity");
    fadeIn->setDuration(1000);
    fadeIn->setStartValue(0);
    fadeIn->setEndValue(1);
    fadeIn->start(QAbstractAnimation::DeleteWhenStopped);

    connect(m_typeTimer, &QTimer::timeout, this, [=]() {
        if (m_typePos < m_currentDisplayText.length()) {
            eventLabel1->setText(m_currentDisplayText.left(++m_typePos));
        } else {
            m_typeTimer->stop();
        }
    });

    connect(m_engine, &LifeEngine::gameUpdated, this, &LifeWindow::onGameUpdated);
    connect(m_engine, &LifeEngine::gameOver, this, &LifeWindow::onGameOver);

    showStartPage();
}

LifeWindow::~LifeWindow() {}

void LifeWindow::onStartClicked() {
    m_engine->startNewLife();
    logText->clear();
    showGamePage();
}

void LifeWindow::onChoiceMade(int index) {
    m_engine->makeChoice(index);
    animateButton(m_choiceButtons[index]);
}

void LifeWindow::onGameUpdated() {
    updateUI();

    QString desc = m_engine->currentEventDescription();
    int age = m_engine->currentAge();

    QString logLine;

    if (!desc.isEmpty()) {
        // 高亮特殊关键词
        if (desc.contains("恋") || desc.contains("结婚") || desc.contains("创业") ||
            desc.contains("升入") || desc.contains("大学") || desc.contains("修仙") ||
            desc.contains("孩子") || desc.contains("道长") || desc.contains("悟道")) {
            logLine = QString("<span style='color:#d63384; font-weight:bold;'>【%1岁】%2</span>")
                          .arg(age).arg(desc);
        } else {
            logLine = QString("【%1岁】%2").arg(age).arg(desc);
        }
    } else {
        logLine = QString("<span style='color:#999;'>【%1岁】这一年平安无事</span>").arg(age);
    }

    logText->append(logLine);
    logText->verticalScrollBar()->setValue(logText->verticalScrollBar()->maximum());
}

void LifeWindow::onGameOver(QString summary) {
    showSummaryPage();

    int attrIndex = summary.indexOf("最终属性：");
    QString logPart, attrPart;

    if (attrIndex != -1) {
        logPart = summary.left(attrIndex).toHtmlEscaped().replace("\n", "<br>");
        attrPart = summary.mid(attrIndex).toHtmlEscaped().replace("\n", "<br>");
    } else {
        logPart = summary.toHtmlEscaped().replace("\n", "<br>");
        attrPart = "（未能提取属性信息）";
    }

    QString ratingIcon, ratingText;

    if (summary.contains("传奇人生")) {
        ratingIcon = "🌟";
        ratingText = "<span style='color:gold;font-weight:bold;'>传奇人生</span>";
    } else if (summary.contains("优秀人生")) {
        ratingIcon = "🏆";
        ratingText = "<span style='color:green;font-weight:bold;'>优秀人生</span>";
    } else if (summary.contains("平凡人生")) {
        ratingIcon = "📘";
        ratingText = "<span style='color:#555;font-weight:bold;'>平凡人生</span>";
    } else if (summary.contains("艰难人生")) {
        ratingIcon = "💤";
        ratingText = "<span style='color:darkorange;font-weight:bold;'>艰难人生</span>";
    } else if (summary.contains("悲惨人生")) {
        ratingIcon = "☠️";
        ratingText = "<span style='color:red;font-weight:bold;'>悲惨人生</span>";
    } else if (summary.contains("修仙") || summary.contains("羽化飞升")) {
        ratingIcon = "🕊️";
        ratingText = "<span style='color:purple;font-weight:bold;'>羽化飞升</span>";
    }

    QString formatted =
        "<h2 style='color:#4CAF50;'>🎉 游戏结束 · 人生总结</h2>"
        "<hr>"
        "<div style='font-size:14px; font-family:Microsoft YaHei; color:#333;'>" + logPart + "</div>"
        "<hr>"
        "<h3>📊 评价结果： " + ratingIcon + " " + ratingText + "</h3>"
        "<div style='background:#f9f9f9; border-radius:8px; padding:10px; font-family:Microsoft YaHei;'>"
        "<b>最终属性：</b><br><div style='font-size:13px;'>" + attrPart + "</div>"
        "</div>";


    summaryTextEdit->setHtml(formatted);
    summaryTextEdit->moveCursor(QTextCursor::Start);
}




void LifeWindow::updateUI() {
    Attribute attr = m_engine->currentAttributes();
    ageLabel->setText(QString("年龄: %1").arg(m_engine->currentAge()));
    intelLabel->setText(QString("智力: %1").arg(attr.intelligence));
    wealthLabel->setText(QString("财富: %1").arg(attr.wealth));
    healthLabel->setText(QString("健康: %1").arg(attr.health));
    happyLabel->setText(QString("幸福: %1").arg(attr.happiness));
    appearLabel->setText(QString("颜值: %1").arg(attr.appearance));

    QString text = m_engine->currentEventDescription();
    if (!text.isEmpty()) {
        typeWriterEffect(text);
        nextYearButton->setVisible(false);
    } else {
        typeWriterEffect(QString("年龄 %1：这一年平安无事").arg(m_engine->currentAge()));
        nextYearButton->setVisible(true);
    }

    QStringList choices = m_engine->currentChoices();
    bool hasChoices = !choices.isEmpty();
    for (int i = 0; i < 4; ++i) {
        if (i < choices.size()) {
            m_choiceButtons[i]->setText(choices[i]);
            m_choiceButtons[i]->setVisible(true);
        } else {
            m_choiceButtons[i]->setVisible(false);
        }
    }

    // 如果没有事件，就隐藏所有按钮，仅显示“下一年”
    nextYearButton->setVisible(!hasChoices);
}

void LifeWindow::typeWriterEffect(const QString &text) {
    m_currentDisplayText = text;
    m_typePos = 0;
    eventLabel1->clear();
    m_typeTimer->start(40);
}


void LifeWindow::showStartPage() {
    stackedWidget->setCurrentWidget(startPage);
}

void LifeWindow::showGamePage() {
    stackedWidget->setCurrentWidget(gamePage);
}

void LifeWindow::showSummaryPage() {
    stackedWidget->setCurrentWidget(summaryPage);
}

void LifeWindow::animateButton(QPushButton *button) {
    QPropertyAnimation *anim = new QPropertyAnimation(button, "geometry");
    anim->setDuration(200);
    anim->setKeyValueAt(0, button->geometry());
    anim->setKeyValueAt(0.5, button->geometry().adjusted(-5, -5, 5, 5));
    anim->setKeyValueAt(1, button->geometry());
    anim->start(QAbstractAnimation::DeleteWhenStopped);
}

void LifeWindow::resizeEvent(QResizeEvent *event) {
    QMainWindow::resizeEvent(event);

    if (container) {
        int x = (width() - container->width()) / 2;
        int y = (height() - container->height()) / 2;
        container->move(x, y);
    }
}




