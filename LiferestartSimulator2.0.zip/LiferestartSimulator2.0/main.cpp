#include <QApplication>
#include "LifeWindow.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // 设置样式，可选
    QApplication::setStyle("Fusion");

    // 启动主窗口
    LifeWindow window;
    window.show();

    return app.exec();
}
