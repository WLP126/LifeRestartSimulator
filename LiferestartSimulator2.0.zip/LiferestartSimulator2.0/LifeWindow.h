#ifndef LIFEWINDOW_H
#define LIFEWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include <QPushButton>
#include <QLabel>
#include <QTextEdit>
#include <QTextBrowser>
#include <QTimer>
#include <QGraphicsView>
#include <QGraphicsScene>
#include "LifeEngine.h"

class LifeWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit LifeWindow(QWidget *parent = nullptr);
    ~LifeWindow();

private slots:
    void onStartClicked();              // 点击“重开人生”
    void onChoiceMade(int index);      // 用户点击某个选项
    void onGameUpdated();              // 游戏状态更新
    void onGameOver(QString summary);  // 游戏结束

private:
    // 页面跳转
    void showStartPage();
    void showGamePage();
    void showSummaryPage();

    // UI 更新辅助
    void updateUI();
    void typeWriterEffect(const QString &text);  // 打字机动画
    void animateButton(QPushButton *button);     // 按钮点击动画

    // 主功能组件
    LifeEngine *m_engine;
    QTimer *m_typeTimer;

    // 页面堆叠容器
    QStackedWidget *stackedWidget;
    QWidget *startPage;
    QWidget *gamePage;
    QWidget *summaryPage;
    QWidget *container;

    // 控件引用
    QLabel *ageLabel;
    QLabel *intelLabel;
    QLabel *wealthLabel;
    QLabel *healthLabel;
    QLabel *happyLabel;
    QLabel *appearLabel;
    QLabel *eventLabel1;

    QTextBrowser *logText;         // 人生记录日志窗口
    QTextEdit *summaryTextEdit;   // 最终总结展示窗口

    QPushButton *m_choiceButtons[4]; // 最多4个选项按钮
    QPushButton *nextYearButton;

    // 打字机文本数据
    QString m_currentDisplayText;
    int m_typePos = 0;

protected:
    void resizeEvent(QResizeEvent *event) override;

};

#endif // LIFEWINDOW_H

